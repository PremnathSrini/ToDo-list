package classes;

import javax.swing.JFrame;

public class ToDoList {
	
	public static void main(String args[])
	{
		AppFrame frame = new AppFrame();
		
	}
}
